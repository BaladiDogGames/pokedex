<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
    "http://www.w3.org/TR/html4/strict.dtd">
<!-- Deanna L. Andru, November 3rd, 2014-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Registration Summary</title>
</head>
<body>
<h1>Conference Registration</h1>
<p>You have successfully registered for the conference.</p>

</body>
</html>


