<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
    "http://www.w3.org/TR/html4/strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Professional Conference</title>
</head>
<body>
<h1>Personal Information</h1>
<hr />
<form method="post" action="RegisterCompany.php">
<p>First Name: 
<input type="text" name="first" />
Last Name: 
<input type="text" name="last" /></p>
<p>Address: 
<input type="text" name="address" />
City:
<input type="text" name="city" /></p>
<p>State: 
<input type="text" name="state" />
Zip: 
<input type="text" name="zip" /></p>
<p>Phone Number:  
<input type="text" name="phone" /></p>
<p>E-mail:  
<input type="text" name="email" /></p>

<input type="submit" name="register"
value="Next" /></br></br>

<input type="reset" name="reset"
value="Start Over" /></br></br>
</form>
<hr />
</body>
</html>
